<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e(config('app.name')); ?></title>
    <link rel= "stylesheet" href=" <?php echo e(asset('/css/bootstrap.min.css')); ?>">

   </head>
   <body>

    <div class='container'>
     <h1>Create Product</h1>

      <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
               <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($message); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
      </div>
      <?php endif; ?>

     <form action="/products"method="post" enctype="multipart/form-data">
            <input type = "hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
             <?php echo e(csrf_field()); ?>


            <div class="form-group">
                <label for="name">Name</label>
                <input type = "text" id="name"name="name"class="form-control">
            </div>

            <div class="form-group">
                <label for="discription">Discription</label>
                <textarea id="discription"name="discription"class="form-control"></textarea>
            </div>

            <div class="form-group">
                <label for="category_id">Category_id</label>

                <select id="category_id"name="category_id"class="form-control">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>
            </div>

            <div class="form-group">
                <label for="govern_id">Government</label>
                <select id="govern_id"name="govern_id"class="form-control" >
                    <option value="" selected disabled>select government    </option>
                    <?php $__currentLoopData = \App\Models\Governorate::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $governorate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($governorate->id); ?>"><?php echo e($governorate->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-group">
                <label for="">Region</label>
                <select name="region_id" class="custom-select">
                    
                </select>
            </div>

            <div class="form-group">
                <label for="photo">Photo</label>
                <input type="file" id="photo"name="photo" class="form-control">
            </div>

            <div class="form-group">
                <button class="btn btn-primary">Save</button>
            </div>

        </form>
    </div>
</body>
<!-- jquery -->
<script src="<?php echo e(URL::asset('js/jquery-3.3.1.min.js')); ?>"></script>
<!-- plugins-jquery -->
<script src="<?php echo e(URL::asset('js/plugins-jquery.js')); ?>"></script>
    <script>
        $(document).ready(function () {
            $('select[name="govern_id"]').on('change', function () {
                var government_id = $(this).val();
                
                if (government_id) {
                    $.ajax({
                        url: "<?php echo e(URL::to('region')); ?>/" + government_id,
                        type: "GET",
                        dataType: "json",
                        success: function (data) {
                            $('select[name="region_id"]').empty();
                            $.each(data, function (key, value) {
                                $('select[name="region_id"]').append('<option value="' + key + '">' + value + '</option>');
                            });
                        },
                    });
                } else {
                    console.log('AJAX load did not work');
                }
            });
        });
    </script>
</html>
<?php /**PATH C:\Users\ACA-w10\Desktop\New folder (2)\graduation-project-master\resources\views/product/create.blade.php ENDPATH**/ ?>