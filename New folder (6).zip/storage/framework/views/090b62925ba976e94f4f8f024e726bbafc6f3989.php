<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e(config('app.name')); ?></title>
    <link rel= "stylesheet" href=" <?php echo e(asset('/css/bootstrap.min.css')); ?>">

   </head>
   <body>

    <div class='container'>
     <h1>Create Category</h1>

      <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
               <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($message); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
      </div>
      <?php endif; ?>

     <form action="/categories"method="post" enctype="multipart/form-data">
            <input type = "hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
             <?php echo e(csrf_field()); ?>


            <div class="form-group">
                <label for="name">Name</label>
                <input type = "text" id="name"name="name"class="form-control">
            </div>

            <div class="form-group">
                <label for="discription">Discription</label>
                <textarea id="discription"name="discription"class="form-control"></textarea>
            </div>

            <div class="form-group">
                <label for="parent_id">Parent</label>
                <select id="parent_id"name="parent_id"class="form-control">
                    <option value="">No Parent</option>

                    <?php $__currentLoopData = $parents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($parent->id); ?>"><?php echo e($parent->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>
            </div>

            <div class="form-group">
                <label for="photo">Photo</label>
                <input type="file" id="photo"name="photo"class="form-control">
            </div>

            <div class="form-group">
                <button class="btn btn-primary">Save</button>
            </div>

        </form>
    </div>
</body>
</html>
<?php /**PATH C:\Users\ACA-w10\Desktop\New folder (2)\graduation-project-master\resources\views/category/create.blade.php ENDPATH**/ ?>