<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e(config('app.name')); ?></title>
    <link rel= "stylesheet" href=" <?php echo e(asset('/css/bootstrap.min.css')); ?>">

</head>
<body>
    <div class='container'>

     <h1>Show Category</h1>

    <div class="table-responsive">
    <table class="table">

        <thead>
            <tr>
              <th>Id</th>
              <th>Name</th>
              <th>Discription</th>
              <th>Parent_id</th>
              <th>Image</th>
              <th>Created At</th>

            </tr>
        </thead>

        <tbody>
         <tr>
              <td><?php echo e($category->id); ?></td>
              <td><?php echo e($category->name); ?></td>
              <td><?php echo e($category->discription); ?></td>
              <td><?php echo e($category->parent_id); ?></td>
              <td> <img src="<?php echo e($category->getFirstMediaUrl()); ?>" height="100px" width="100px"></td>
              <td> <?php echo e($category->created_at); ?></td>

         </tr>

        </tbody>
    </table>
         </div>
        </div>

</body>
</html>
<?php /**PATH C:\Users\Misk ITs\Desktop\New folder (6)\resources\views/category/show.blade.php ENDPATH**/ ?>