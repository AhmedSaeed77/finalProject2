<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e(config('app.name')); ?></title>
    <link rel="stylesheet" href=" <?php echo e(asset('/css/bootstrap.min.css')); ?>">

</head>

<body>
    <div class='container'>

        <h1 class="mb-3"><?php echo e($title); ?>

            <small><a href="/products/create">create</a></small>
        </h1>

        <?php if($flashMessage): ?>
        <div class="alert alert-success">
            <?php echo e($flashMessage); ?>

        </div>
        <?php endif; ?>

        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Discription</th>
                        <th>category_id</th>
                        <th>Image</th>
                        <th>Created At</th>
                        <th></th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td> <?php echo e($product->id); ?></td>
                        <td><a href="<?php echo e(url('products', $product->id)); ?>"> <?php echo e($product->name); ?></a></td>
                        <td> <?php echo e($product->discription); ?></td>
                        <td> <?php echo e($product->category_id); ?></td>
                        <!-- <td> <img src="<?php echo e($product->getFirstMediaUrl()); ?>" height="100px" width="100px"></td> -->
                        <td> <img src="<?php echo e(asset('/images/products/' . $product->photo)); ?>" height="100px" width="100px"></td>
                        <td> <?php echo e($product->created_at); ?></td>
                        <td><a href="<?php echo e(url('products/edit', $product->id)); ?>" class="btn btn-sm btn-dark">Edit</a></td>

                        <td>
                            <form action="/products/<?php echo e($product->id); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="_method" value="delete">
                                <button class="btn btn-sm btn-danger">Delete</button>
                            </form>
                        </td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

</body>

</html>
<?php /**PATH C:\Users\ACA-w10\Desktop\New folder (2)\graduation-project-master\resources\views/product/index.blade.php ENDPATH**/ ?>